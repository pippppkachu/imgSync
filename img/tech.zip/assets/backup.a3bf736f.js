import{d as e}from"./_pinia@2.1.7@pinia.398ecc2f.js";const t=e("backup",{state:()=>({cancelBackup:!1}),actions:{setCancelBackup(a){this.cancelBackup=a}}});export{t as u};
