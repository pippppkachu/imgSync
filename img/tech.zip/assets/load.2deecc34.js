const o=""+new URL("load.558d0f7a.svg",import.meta.url).href;export{o as _};
